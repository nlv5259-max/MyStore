﻿using System.Linq;
using System.Web.Mvc;
using MyStore.Models;

namespace MyStore.Controllers
{
    public class AccountController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            var user = db.Users.FirstOrDefault(
                x => x.Username == username &&
                     x.Password == password);

            if (user == null)
            {
                ViewBag.Error = "Sai tài khoản hoặc mật khẩu!";
                return View();
            }

            Session["Username"] = user.Username;
            Session["UserRole"] = user.UserRole;

            if (user.UserRole == "A")
                return RedirectToAction("Index", "Home", new { area = "Admin" });

            return RedirectToAction("Index", "Store");
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(string username, string password)
        {
            if (db.Users.Any(x => x.Username == username))
            {
                ViewBag.Error = "Tên đăng nhập đã tồn tại!";
                return View();
            }

            var user = new User
            {
                Username = username,
                Password = password,
                UserRole = "C"
            };

            db.Users.Add(user);
            db.SaveChanges();

            return RedirectToAction("Login");
        }
    }
}