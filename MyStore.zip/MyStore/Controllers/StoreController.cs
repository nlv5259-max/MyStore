﻿
using MyStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace MyStore.Controllers
{
    public class CartItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }

    public class StoreController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        private List<CartItem> GetCart()
        {
            var cart = Session["Cart"] as List<CartItem>;

            if (cart == null)
            {
                cart = new List<CartItem>();
                Session["Cart"] = cart;
            }

            return cart;
        }

        public ActionResult Index()
        {
            return View(db.Products.ToList());
        }

        public ActionResult Details(int id)
        {
            var product = db.Products.Find(id);

            if (product == null)
                return HttpNotFound();

            return View(product);
        }

        public ActionResult AddToCart(int id)
        {
            var product = db.Products.Find(id);

            if (product == null)
                return HttpNotFound();

            var cart = GetCart();
            var item = cart.FirstOrDefault(x => x.Product.ProductID == id);

            if (item == null)
                cart.Add(new CartItem { Product = product, Quantity = 1 });
            else
                item.Quantity++;

            return RedirectToAction("Cart");
        }

        public ActionResult Cart()
        {
            return View(GetCart());
        }

        public ActionResult RemoveFromCart(int id)
        {
            var cart = GetCart();
            cart.RemoveAll(x => x.Product.ProductID == id);

            return RedirectToAction("Cart");
        }
        [HttpGet]
        public ActionResult Checkout()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Checkout(string fullName, string phone, string address, string paymentMethod)
        {
            var cart = GetCart();

            if (cart.Count == 0)
                return RedirectToAction("Index");

            var order = new Order
            {
                CustomerID = 3,
                OrderDate = DateTime.Now,
                TotalAmount = cart.Sum(x => x.Product.ProductPrice * x.Quantity),
                PaymentStatus = "Chờ xử lý",
                ShippingAddress = address,
                DeliveryMethod = "Giao hàng tận nơi",
                PaymentMethod = paymentMethod
            };

            db.Orders.Add(order);
            db.SaveChanges();

            foreach (var item in cart)
            {
                db.OrderDetails.Add(new OrderDetail
                {
                    OrderID = order.OrderID,
                    ProductID = item.Product.ProductID,
                    Quantity = item.Quantity,
                    UnitPrice = item.Product.ProductPrice
                });
            }

            db.SaveChanges();
            Session["Cart"] = null;

            return Content("Đặt hàng thành công! Mã đơn hàng: " + order.OrderID);
        }
    }
}

